SMART TRAFFIC LIGHT - DEBUGGED VERSION

Run:
  javac TrafficLightController.java
  java TrafficLightController

Debug fixes:
- Timer now uses a 250 ms tick and subtracts the actual tick interval.
- Start/Resume chooses the higher-density lane first (ties start at Lane A).
- Applying density updates recomputes both lanes' green times and the active phase.
- Lane A/B emergency and night caution modes are independent.
- Both-high traffic receives equal green time and both lanes continue alternating.
- In normal mode only one lane is green at a time; yellow transition and all-red clearance are included.

Interview explanation for both lanes high:
The controller uses a weighted green-time allocation. If both lanes have the same high density,
they receive equal green durations (6 seconds each in this demo), then alternate safely. In a
real system, queue length, waiting time, maximum green, pedestrian phases, and emergency vehicle
detection should also be considered to avoid starvation and ensure safe operation.

This is a simulation with manually selected density values, not a certified real-world controller.
