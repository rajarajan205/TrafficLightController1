import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

/**
 * Smart Traffic Light Management System.
 * Lane-adaptive Java Swing simulation with density-based green-time allocation.
 * Traffic density is manually selected; no real sensors/hardware are connected.
 */
public class TrafficLightController extends JFrame {
    private static final Color BG = new Color(14, 20, 35);
    private static final Color PANEL = new Color(25, 34, 54);
    private static final Color PANEL_LIGHT = new Color(36, 48, 72);
    private static final Color TEXT = new Color(235, 241, 250);
    private static final Color MUTED = new Color(153, 168, 191);
    private static final Color BLUE = new Color(71, 145, 255);
    private static final Color GREEN = new Color(48, 214, 130);
    private static final Color YELLOW = new Color(255, 193, 71);
    private static final Color RED = new Color(255, 91, 105);

    private final JComboBox<String> densityA = new JComboBox<>(new String[]{"Low", "Medium", "High"});
    private final JComboBox<String> densityB = new JComboBox<>(new String[]{"Low", "Medium", "High"});
    private final JLabel status = label("READY • Set lane densities and start the simulation", 12, MUTED, Font.PLAIN);
    private final JLabel modeValue = label("NORMAL", 15, BLUE, Font.BOLD);
    private final JLabel phaseValue = label("READY", 15, GREEN, Font.BOLD);
    private final JLabel timerValue = label("—", 15, YELLOW, Font.BOLD);
    private final JLabel cyclesValue = label("0", 15, TEXT, Font.BOLD);
    private final JProgressBar progress = new JProgressBar(0, 100);

    private final LanePanel laneA = new LanePanel("LANE A", "North Avenue");
    private final LanePanel laneB = new LanePanel("LANE B", "Central Junction");

    private final Timer signalTimer = new Timer(250, e -> tick());
    private final Timer nightTimer = new Timer(500, e -> blinkNightSignal());
    private final Timer progressTimer = new Timer(100, e -> updateProgress());

    private int greenMsA = 6000;
    private int greenMsB = 6000;
    private final int yellowMs = 2000;
    private final int clearanceMs = 1000;
    private int activeLane = 0; // 0 = A, 1 = B
    private int phase = 0;      // 0 = green, 1 = yellow, 2 = all-red clearance
    private int remainingMs = 0;
    private int completedCycles = 0;
    private boolean running = false;
    private boolean nightYellowOn = true;
    private String mode = "NORMAL"; // NORMAL, EMERGENCY_A/B, NIGHT_A/B

    public TrafficLightController() {
        super("Smart Traffic Light Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1000, 760));
        setSize(1180, 850);
        setLocationRelativeTo(null);
        getContentPane().setBackground(BG);
        setLayout(new BorderLayout());

        add(buildHeader(), BorderLayout.NORTH);
        add(buildMain(), BorderLayout.CENTER);
        add(buildFooter(), BorderLayout.SOUTH);

        recalculateGreenTimes();
        updateDensityLabels();
        setNormalSignals();
        progressTimer.start();
    }

    private JPanel buildHeader() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(BG);
        p.setBorder(new EmptyBorder(18, 24, 14, 24));
        JPanel titles = new JPanel();
        titles.setOpaque(false);
        titles.setLayout(new BoxLayout(titles, BoxLayout.Y_AXIS));
        titles.add(label("INTELLIGENT MOBILITY / ADAPTIVE SIGNAL CONTROL", 11, BLUE, Font.BOLD));
        titles.add(Box.createVerticalStrut(4));
        titles.add(label("Smart Traffic Light Management", 27, TEXT, Font.BOLD));
        titles.add(Box.createVerticalStrut(3));
        titles.add(label("Density-based green allocation • Emergency priority • Night caution", 13, MUTED, Font.PLAIN));
        p.add(titles, BorderLayout.WEST);
        JLabel badge = label("● SIMULATION READY", 11, GREEN, Font.BOLD);
        badge.setOpaque(true);
        badge.setBackground(PANEL);
        badge.setBorder(new EmptyBorder(9, 12, 9, 12));
        p.add(badge, BorderLayout.EAST);
        return p;
    }

    private JPanel buildMain() {
        JPanel root = new JPanel(new BorderLayout(12, 12));
        root.setOpaque(false);
        root.setBorder(new EmptyBorder(0, 24, 14, 24));

        JPanel densities = panel();
        densities.setLayout(new GridLayout(1, 2, 18, 0));
        densities.setBorder(new EmptyBorder(11, 14, 11, 14));
        densities.add(densityControl("LANE A • TRAFFIC DENSITY", densityA));
        densities.add(densityControl("LANE B • TRAFFIC DENSITY", densityB));

        JPanel laneRow = new JPanel(new GridLayout(1, 2, 14, 0));
        laneRow.setOpaque(false);
        laneRow.setPreferredSize(new Dimension(900, 410));
        laneRow.add(laneA);
        laneRow.add(laneB);

        JPanel controls = panel();
        controls.setLayout(new GridLayout(2, 4, 8, 8));
        controls.setBorder(new EmptyBorder(10, 10, 10, 10));
        JButton start = button("▶ Start / Resume Adaptive Mode", BLUE, Color.WHITE);
        JButton stop = button("■ Stop Cycle", PANEL_LIGHT, TEXT);
        JButton apply = button("Apply Densities", PANEL_LIGHT, TEXT);
        JButton reset = button("Reset", PANEL_LIGHT, TEXT);
        JButton emergencyA = button("Emergency: Lane A", new Color(112, 67, 79), Color.WHITE);
        JButton emergencyB = button("Emergency: Lane B", new Color(112, 67, 79), Color.WHITE);
        JButton nightA = button("Night Caution: Lane A", new Color(95, 76, 35), Color.WHITE);
        JButton nightB = button("Night Caution: Lane B", new Color(95, 76, 35), Color.WHITE);
        for (JButton b : new JButton[]{start, stop, apply, reset, emergencyA, emergencyB, nightA, nightB}) controls.add(b);

        JPanel stats = panel();
        stats.setLayout(new BorderLayout(8, 8));
        stats.setBorder(new EmptyBorder(10, 13, 10, 13));
        JPanel statRow = new JPanel(new GridLayout(1, 4, 12, 0));
        statRow.setOpaque(false);
        statRow.add(stat("OPERATING MODE", modeValue));
        statRow.add(stat("ACTIVE PHASE", phaseValue));
        statRow.add(stat("TIME REMAINING", timerValue));
        statRow.add(stat("COMPLETED CYCLES", cyclesValue));
        stats.add(statRow, BorderLayout.NORTH);
        progress.setStringPainted(true);
        progress.setString("SIGNAL PHASE PROGRESS");
        progress.setForeground(BLUE);
        progress.setBackground(PANEL_LIGHT);
        progress.setBorderPainted(false);
        stats.add(progress, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new BorderLayout(0, 5));
        bottom.setOpaque(false);
        bottom.add(stats, BorderLayout.CENTER);
        status.setBorder(new EmptyBorder(4, 2, 0, 2));
        bottom.add(status, BorderLayout.SOUTH);

        JPanel center = new JPanel(new BorderLayout(0, 10));
        center.setOpaque(false);
        center.add(densities, BorderLayout.NORTH);
        center.add(laneRow, BorderLayout.CENTER);
        center.add(controls, BorderLayout.SOUTH);

        root.add(center, BorderLayout.CENTER);
        root.add(bottom, BorderLayout.SOUTH);

        start.addActionListener(e -> startAdaptiveMode());
        stop.addActionListener(e -> stopCycle());
        apply.addActionListener(e -> applyDensities());
        reset.addActionListener(e -> resetSystem());
        emergencyA.addActionListener(e -> setEmergencyMode(0));
        emergencyB.addActionListener(e -> setEmergencyMode(1));
        nightA.addActionListener(e -> setNightMode(0));
        nightB.addActionListener(e -> setNightMode(1));
        return root;
    }

    private JPanel densityControl(String title, JComboBox<String> combo) {
        JPanel p = new JPanel(new BorderLayout(5, 6));
        p.setOpaque(false);
        p.add(label(title, 10, MUTED, Font.BOLD), BorderLayout.NORTH);
        combo.setFont(new Font("SansSerif", Font.BOLD, 13));
        combo.setBackground(PANEL_LIGHT);
        combo.setForeground(TEXT);
        p.add(combo, BorderLayout.CENTER);
        return p;
    }

    private JPanel stat(String title, JLabel value) {
        JPanel p = new JPanel(new GridLayout(2, 1, 0, 3));
        p.setOpaque(false);
        p.add(label(title, 9, MUTED, Font.BOLD));
        p.add(value);
        return p;
    }

    private JPanel buildFooter() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(new Color(10, 15, 27));
        p.setBorder(new EmptyBorder(8, 24, 8, 24));
        p.add(label("SMART MOBILITY • LANE-ADAPTIVE SIMULATION", 9, MUTED, Font.BOLD), BorderLayout.WEST);
        p.add(label("MANUAL DENSITY INPUT • NO HARDWARE CONNECTED", 9, MUTED, Font.PLAIN), BorderLayout.EAST);
        return p;
    }

    private JPanel panel() {
        JPanel p = new JPanel();
        p.setBackground(PANEL);
        p.setBorder(new LineBorder(new Color(49, 63, 91), 1, true));
        return p;
    }

    private static JLabel label(String text, int size, Color color, int style) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("SansSerif", style, size));
        l.setForeground(color);
        return l;
    }

    private static JButton button(String text, Color bg, Color fg) {
        JButton b = new JButton(text);
        b.setFont(new Font("SansSerif", Font.BOLD, 11));
        b.setBackground(bg);
        b.setForeground(fg);
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setOpaque(true);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setMargin(new Insets(9, 8, 9, 8));
        return b;
    }

    private void recalculateGreenTimes() {
        int a = weight((String) densityA.getSelectedItem());
        int b = weight((String) densityB.getSelectedItem());
        int total = 12000;
        int minimum = 4000;
        if (a == b) {
            greenMsA = total / 2;
            greenMsB = total / 2;
        } else {
            greenMsA = (int) Math.round(total * a / (double) (a + b));
            greenMsB = total - greenMsA;
            if (greenMsA < minimum) { greenMsA = minimum; greenMsB = total - minimum; }
            if (greenMsB < minimum) { greenMsB = minimum; greenMsA = total - minimum; }
        }
    }

    private int weight(String d) {
        if ("High".equals(d)) return 3;
        if ("Medium".equals(d)) return 2;
        return 1;
    }

    private void updateDensityLabels() {
        int a = weight((String) densityA.getSelectedItem());
        int b = weight((String) densityB.getSelectedItem());
        laneA.setDensity((String) densityA.getSelectedItem(), greenMsA, a > b);
        laneB.setDensity((String) densityB.getSelectedItem(), greenMsB, b > a);
    }

    private void applyDensities() {
        recalculateGreenTimes();
        updateDensityLabels();
        if (running && "NORMAL".equals(mode)) {
            // If one lane now has higher density, prioritize it immediately.
            int weightA = weight((String) densityA.getSelectedItem());
            int weightB = weight((String) densityB.getSelectedItem());
            if (weightA > weightB) {
                activeLane = 0;
            } else if (weightB > weightA) {
                activeLane = 1;
            }
            // Equal densities preserve the currently active lane.
            phase = 0;
            remainingMs = activeLane == 0 ? greenMsA : greenMsB;
        }
        if ("NORMAL".equals(mode)) setNormalSignals();
        status.setText("Densities applied: A = " + densityA.getSelectedItem()
                + ", B = " + densityB.getSelectedItem()
                + ". Green timing recalculated for both lanes.");
    }

    private void startAdaptiveMode() {
        nightTimer.stop();
        mode = "NORMAL";
        running = true;
        recalculateGreenTimes();
        updateDensityLabels();
        // Start with whichever lane has the higher density; equal density starts at A.
        int a = weight((String) densityA.getSelectedItem());
        int b = weight((String) densityB.getSelectedItem());
        activeLane = (b > a) ? 1 : 0;
        phase = 0;
        remainingMs = activeLane == 0 ? greenMsA : greenMsB;
        modeValue.setText("NORMAL");
        modeValue.setForeground(BLUE);
        setNormalSignals();
        signalTimer.setDelay(250);
        signalTimer.start();
        status.setText("Adaptive operation running. Higher-density lane receives more green time.");
    }

    private void stopCycle() {
        running = false;
        signalTimer.stop();
        timerValue.setText("—");
        status.setText("Signal cycle stopped.");
    }

    private void tick() {
        if (!running || !"NORMAL".equals(mode)) return;
        remainingMs -= signalTimer.getDelay();
        if (remainingMs <= 0) {
            if (phase == 0) {
                phase = 1;
                remainingMs = yellowMs;
            } else if (phase == 1) {
                phase = 2;
                remainingMs = clearanceMs;
            } else {
                activeLane = 1 - activeLane;
                phase = 0;
                remainingMs = activeLane == 0 ? greenMsA : greenMsB;
                if (activeLane == 0) {
                    completedCycles++;
                    cyclesValue.setText(String.valueOf(completedCycles));
                }
            }
            setNormalSignals();
        } else {
            timerValue.setText(String.format("%.1f s", remainingMs / 1000.0));
        }
    }

    private void setEmergencyMode(int lane) {
        signalTimer.stop();
        nightTimer.stop();
        running = false;
        mode = lane == 0 ? "EMERGENCY_A" : "EMERGENCY_B";
        laneA.setPhase(lane == 0 ? "GREEN" : "RED");
        laneB.setPhase(lane == 1 ? "GREEN" : "RED");
        modeValue.setText(lane == 0 ? "EMERGENCY • A" : "EMERGENCY • B");
        modeValue.setForeground(RED);
        phaseValue.setText(lane == 0 ? "A GREEN / B RED" : "B GREEN / A RED");
        phaseValue.setForeground(GREEN);
        timerValue.setText("Priority");
        progress.setValue(0);
        progress.setString("EMERGENCY PRIORITY ACTIVE");
        status.setText("Emergency simulation: selected lane green, other lane red.");
    }

    private void setNightMode(int lane) {
        signalTimer.stop();
        running = false;
        mode = lane == 0 ? "NIGHT_A" : "NIGHT_B";
        nightYellowOn = true;
        if (lane == 0) {
            laneA.setNightYellow(true);
            laneB.setPhase("RED");
        } else {
            laneA.setPhase("RED");
            laneB.setNightYellow(true);
        }
        modeValue.setText(lane == 0 ? "NIGHT • A" : "NIGHT • B");
        modeValue.setForeground(YELLOW);
        phaseValue.setText(lane == 0 ? "A CAUTION / B RED" : "B CAUTION / A RED");
        phaseValue.setForeground(YELLOW);
        timerValue.setText("Caution");
        progress.setValue(0);
        progress.setString("SELECTED LANE YELLOW CAUTION");
        nightTimer.start();
        status.setText("Night caution: selected lane blinks yellow; other lane remains red.");
    }

    private void blinkNightSignal() {
        if (!mode.startsWith("NIGHT")) return;
        nightYellowOn = !nightYellowOn;
        if ("NIGHT_A".equals(mode)) {
            laneA.setNightYellow(nightYellowOn);
            laneB.setPhase("RED");
        } else {
            laneB.setNightYellow(nightYellowOn);
            laneA.setPhase("RED");
        }
    }

    private void setNormalSignals() {
        if (mode.startsWith("EMERGENCY") || mode.startsWith("NIGHT")) return;
        if (phase == 0) {
            laneA.setPhase(activeLane == 0 ? "GREEN" : "RED");
            laneB.setPhase(activeLane == 1 ? "GREEN" : "RED");
            phaseValue.setText(activeLane == 0 ? "LANE A GREEN" : "LANE B GREEN");
            phaseValue.setForeground(GREEN);
        } else if (phase == 1) {
            laneA.setPhase(activeLane == 0 ? "YELLOW" : "RED");
            laneB.setPhase(activeLane == 1 ? "YELLOW" : "RED");
            phaseValue.setText(activeLane == 0 ? "LANE A YELLOW" : "LANE B YELLOW");
            phaseValue.setForeground(YELLOW);
        } else {
            laneA.setPhase("RED");
            laneB.setPhase("RED");
            phaseValue.setText("ALL-RED CLEARANCE");
            phaseValue.setForeground(RED);
        }
        timerValue.setText(remainingMs > 0 ? String.format("%.1f s", remainingMs / 1000.0) : "—");
        modeValue.setText("NORMAL");
        modeValue.setForeground(BLUE);
    }

    private void updateProgress() {
        if (!running || !"NORMAL".equals(mode)) return;
        int duration = phase == 0 ? (activeLane == 0 ? greenMsA : greenMsB)
                : phase == 1 ? yellowMs : clearanceMs;
        if (duration > 0) {
            progress.setValue(Math.max(0, Math.min(100, (int) (100.0 * (duration - remainingMs) / duration))));
            progress.setString(phaseValue.getText());
        }
    }

    private void resetSystem() {
        signalTimer.stop();
        nightTimer.stop();
        running = false;
        mode = "NORMAL";
        densityA.setSelectedItem("Low");
        densityB.setSelectedItem("Low");
        activeLane = 0;
        phase = 0;
        remainingMs = 0;
        completedCycles = 0;
        cyclesValue.setText("0");
        recalculateGreenTimes();
        updateDensityLabels();
        laneA.setPhase("RED");
        laneB.setPhase("RED");
        modeValue.setText("NORMAL");
        modeValue.setForeground(BLUE);
        phaseValue.setText("READY");
        phaseValue.setForeground(GREEN);
        timerValue.setText("—");
        progress.setValue(0);
        progress.setString("SIGNAL PHASE PROGRESS");
        status.setText("Reset complete. Choose densities and start adaptive operation.");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) { }
            new TrafficLightController().setVisible(true);
        });
    }

    private static class LanePanel extends JPanel {
        private final JLabel densityLabel = label("Traffic density: LOW", 12, MUTED, Font.BOLD);
        private final JLabel greenLabel = label("Green allocation: 6.0 s", 12, GREEN, Font.BOLD);
        private final JLabel signalLabel = label("SIGNAL: RED", 14, RED, Font.BOLD);
        private final Lamp red = new Lamp(RED);
        private final Lamp yellow = new Lamp(YELLOW);
        private final Lamp green = new Lamp(GREEN);

        LanePanel(String name, String location) {
            setBackground(PANEL);
            setLayout(new BorderLayout(6, 8));
            setBorder(new EmptyBorder(12, 14, 12, 14));
            JPanel heading = new JPanel();
            heading.setOpaque(false);
            heading.setLayout(new BoxLayout(heading, BoxLayout.Y_AXIS));
            heading.add(label(name, 15, TEXT, Font.BOLD));
            heading.add(Box.createVerticalStrut(3));
            heading.add(label(location, 11, MUTED, Font.PLAIN));
            add(heading, BorderLayout.NORTH);

            JPanel housing = new JPanel();
            housing.setBackground(new Color(8, 13, 24));
            housing.setBorder(new EmptyBorder(12, 18, 12, 18));
            housing.setLayout(new BoxLayout(housing, BoxLayout.Y_AXIS));
            red.setAlignmentX(Component.CENTER_ALIGNMENT);
            yellow.setAlignmentX(Component.CENTER_ALIGNMENT);
            green.setAlignmentX(Component.CENTER_ALIGNMENT);
            housing.add(red);
            housing.add(Box.createVerticalStrut(7));
            housing.add(yellow);
            housing.add(Box.createVerticalStrut(7));
            housing.add(green);

            JPanel signalCenter = new JPanel(new GridBagLayout());
            signalCenter.setOpaque(false);
            signalCenter.add(housing);
            add(signalCenter, BorderLayout.CENTER);

            JPanel bottom = new JPanel(new GridLayout(3, 1, 3, 3));
            bottom.setOpaque(false);
            bottom.add(densityLabel);
            bottom.add(greenLabel);
            bottom.add(signalLabel);
            add(bottom, BorderLayout.SOUTH);
            setPreferredSize(new Dimension(430, 410));
            setMinimumSize(new Dimension(360, 390));
            setPhase("RED");
        }

        void setDensity(String density, int greenMs, boolean priority) {
            densityLabel.setText("Traffic density: " + density.toUpperCase() + (priority ? " • PRIORITY" : ""));
            densityLabel.setForeground(priority ? GREEN : MUTED);
            greenLabel.setText("Green allocation: " + String.format("%.1f", greenMs / 1000.0) + " s");
        }

        void setPhase(String phase) {
            red.setLit("RED".equals(phase));
            yellow.setLit("YELLOW".equals(phase));
            green.setLit("GREEN".equals(phase));
            signalLabel.setText("SIGNAL: " + phase);
            signalLabel.setForeground("GREEN".equals(phase) ? GREEN : "YELLOW".equals(phase) ? YELLOW : RED);
        }

        void setNightYellow(boolean on) {
            red.setLit(false);
            yellow.setLit(on);
            green.setLit(false);
            signalLabel.setText("NIGHT CAUTION • YELLOW");
            signalLabel.setForeground(YELLOW);
        }
    }

    private static class Lamp extends JPanel {
        private final Color color;
        private boolean lit;

        Lamp(Color color) {
            this.color = color;
            setPreferredSize(new Dimension(66, 66));
            setMinimumSize(new Dimension(66, 66));
            setMaximumSize(new Dimension(66, 66));
            setOpaque(false);
        }

        void setLit(boolean value) {
            lit = value;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(lit ? color : new Color(52, 62, 80));
            g2.fillOval(4, 4, 58, 58);
            if (lit) {
                g2.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), 75));
                g2.setStroke(new BasicStroke(4f));
                g2.drawOval(2, 2, 62, 62);
            }
            g2.setColor(new Color(7, 10, 18));
            g2.setStroke(new BasicStroke(2f));
            g2.drawOval(4, 4, 58, 58);
            g2.dispose();
        }
    }
}
